// Exercício 7: Ordenar três números em ordem crescente

import java.util.Scanner;

public class OrdenarTresNumeros {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite o primeiro número: ");
        double num1 = scanner.nextDouble();
        
        System.out.print("Digite o segundo número: ");
        double num2 = scanner.nextDouble();
        
        System.out.print("Digite o terceiro número: ");
        double num3 = scanner.nextDouble();
        
        double menor, meio, maior;
        
        // Determinar a ordem dos números
        if (num1 <= num2 && num1 <= num3) {
            // num1 é o menor
            menor = num1;
            if (num2 <= num3) {
                meio = num2;
                maior = num3;
            } else {
                meio = num3;
                maior = num2;
            }
        } else if (num2 <= num1 && num2 <= num3) {
            // num2 é o menor
            menor = num2;
            if (num1 <= num3) {
                meio = num1;
                maior = num3;
            } else {
                meio = num3;
                maior = num1;
            }
        } else {
            // num3 é o menor
            menor = num3;
            if (num1 <= num2) {
                meio = num1;
                maior = num2;
            } else {
                meio = num2;
                maior = num1;
            }
        }
        
        System.out.println("Números em ordem crescente: " + menor + " " + meio + " " + maior);
        
        scanner.close();
    }
}