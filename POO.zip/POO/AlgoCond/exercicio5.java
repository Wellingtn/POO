// Exercício 5: Calcular IMC e classificar pessoa

import java.util.Scanner;

public class CalcularIMC {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite o peso (kg): ");
        double peso = scanner.nextDouble();
        
        System.out.print("Digite a altura (m): ");
        double altura = scanner.nextDouble();
        
        // Calcular IMC
        double imc = peso / (altura * altura);
        
        String classificacao;
        
        // Determinar classificação baseada no IMC
        if (imc < 18.5) {
            classificacao = "Abaixo do peso";
        } else if (imc < 25.0) {
            classificacao = "Normal";
        } else if (imc < 30.0) {
            classificacao = "Pré-obeso";
        } else if (imc < 35.0) {
            classificacao = "Obeso classe I";
        } else if (imc < 40.0) {
            classificacao = "Obeso classe II";
        } else {
            classificacao = "Obeso classe III";
        }
        
        System.out.println("\nResultados:");
        System.out.println("Peso: " + peso + " kg");
        System.out.println("Altura: " + altura + " m");
        System.out.println("IMC: " + String.format("%.2f", imc));
        System.out.println("Classificação: " + classificacao);
        
        scanner.close();
    }
}