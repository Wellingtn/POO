// Exercício 4: Calcular média das três maiores notas de quatro provas

import java.util.Scanner;
import java.util.Arrays;

public class MediaTresMaiores {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Digite as quatro notas das provas:");
        
        System.out.print("Nota 1: ");
        double nota1 = scanner.nextDouble();
        
        System.out.print("Nota 2: ");
        double nota2 = scanner.nextDouble();
        
        System.out.print("Nota 3: ");
        double nota3 = scanner.nextDouble();
        
        System.out.print("Nota 4: ");
        double nota4 = scanner.nextDouble();
        
        // Colocar as notas em um array para facilitar a ordenação
        double[] notas = {nota1, nota2, nota3, nota4};
        
        // Ordenar as notas em ordem crescente
        Arrays.sort(notas);
        
        // As três maiores notas são as três últimas após ordenação
        double media = (notas[1] + notas[2] + notas[3]) / 3.0;
        
        System.out.println("\nNotas em ordem crescente:");
        for (int i = 0; i < notas.length; i++) {
            System.out.println("Nota " + (i + 1) + ": " + notas[i]);
        }
        
        System.out.println("\nTrês maiores notas: " + notas[1] + ", " + notas[2] + ", " + notas[3]);
        System.out.println("Média das três maiores notas: " + String.format("%.2f", media));
        
        scanner.close();
    }
}