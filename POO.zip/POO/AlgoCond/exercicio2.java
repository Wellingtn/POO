// Exercício 2: Verificar se aluno foi aprovado ou não

import java.util.Scanner;

public class VerificarAprovacao {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite a nota final do aluno: ");
        double notaFinal = scanner.nextDouble();
        
        if (notaFinal >= 6.0) {
            System.out.println("O aluno foi APROVADO.");
        } else {
            System.out.println("O aluno foi REPROVADO.");
        }
        
        scanner.close();
    }
}