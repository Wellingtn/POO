// Exercício 9: Contar algarismos ímpares e somar algarismos pares de um número de 5 dígitos

import java.util.Scanner;

public class AnalisarAlgarismos {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite um número de 5 dígitos: ");
        int numero = scanner.nextInt();
        
        int contadorImpares = 0;
        int somaPares = 0;
        int temp = numero;
        
        // Verificar se tem 5 dígitos
        if (numero < 10000 || numero > 99999) {
            System.out.println("Por favor, digite um número de exatamente 5 dígitos!");
        } else {
            // Processar cada algarismo
            while (temp > 0) {
                int algarismo = temp % 10; // Pegar o último dígito
                
                if (algarismo % 2 == 0) {
                    // Algarismo é par
                    somaPares += algarismo;
                } else {
                    // Algarismo é ímpar
                    contadorImpares++;
                }
                
                temp = temp / 10; // Remover o último dígito
            }
            
            System.out.println("Número analisado: " + numero);
            System.out.println("Quantidade de algarismos ímpares: " + contadorImpares);
            System.out.println("Soma dos algarismos pares: " + somaPares);
        }
        
        scanner.close();
    }
}