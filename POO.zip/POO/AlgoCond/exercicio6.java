// Exercício 6: Ordenar dois números em ordem crescente

import java.util.Scanner;

public class OrdenarDoisNumeros {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite o primeiro número: ");
        double num1 = scanner.nextDouble();
        
        System.out.print("Digite o segundo número: ");
        double num2 = scanner.nextDouble();
        
        System.out.println("Números em ordem crescente:");
        
        if (num1 <= num2) {
            System.out.println(num1 + " " + num2);
        } else {
            System.out.println(num2 + " " + num1);
        }
        
        scanner.close();
    }
}