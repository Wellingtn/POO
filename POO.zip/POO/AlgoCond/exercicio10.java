// Exercício 10: Converter número para algarismos romanos (1 a 399)

import java.util.Scanner;

public class ConverterRomanos {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite um número entre 1 e 399: ");
        int numero = scanner.nextInt();
        
        if (numero < 1 || numero > 399) {
            System.out.println("Número deve estar entre 1 e 399!");
        } else {
            String romano = converterParaRomano(numero);
            System.out.println("Número: " + numero);
            System.out.println("Em romano: " + romano);
        }
        
        scanner.close();
    }
    
    public static String converterParaRomano(int numero) {
        String resultado = "";
        
        // Centenas
        int centenas = numero / 100;
        if (centenas == 3) {
            resultado += "CCC";
        } else if (centenas == 2) {
            resultado += "CC";
        } else if (centenas == 1) {
            resultado += "C";
        }
        
        // Dezenas
        int dezenas = (numero % 100) / 10;
        if (dezenas == 9) {
            resultado += "XC";
        } else if (dezenas == 8) {
            resultado += "LXXX";
        } else if (dezenas == 7) {
            resultado += "LXX";
        } else if (dezenas == 6) {
            resultado += "LX";
        } else if (dezenas == 5) {
            resultado += "L";
        } else if (dezenas == 4) {
            resultado += "XL";
        } else if (dezenas == 3) {
            resultado += "XXX";
        } else if (dezenas == 2) {
            resultado += "XX";
        } else if (dezenas == 1) {
            resultado += "X";
        }

        // Unidades
        int unidades = numero % 10;
        if (unidades == 9) {
            resultado += "IX";
        } else if (unidades == 8) {
            resultado += "VIII";
        } else if (unidades == 7) {
            resultado += "VII";
        } else if (unidades == 6) {
            resultado += "VI";
        } else if (unidades == 5) {
            resultado += "V";
        } else if (unidades == 4) {
            resultado += "IV";
        } else if (unidades == 3) {
            resultado += "III";
        } else if (unidades == 2) {
            resultado += "II";
        } else if (unidades == 1) {
            resultado += "I";
        }

        return resultado;
    }
}