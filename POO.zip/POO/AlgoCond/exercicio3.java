// Exercício 3: Calcular conceito baseado na média e faltas

import java.util.Scanner;

public class CalcularConceito {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite a primeira nota: ");
        double nota1 = scanner.nextDouble();
        
        System.out.print("Digite a segunda nota: ");
        double nota2 = scanner.nextDouble();
        
        System.out.print("Digite a terceira nota: ");
        double nota3 = scanner.nextDouble();
        
        System.out.print("Digite a quantidade de faltas: ");
        int faltas = scanner.nextInt();
        
        // Calcular média aritmética
        double media = (nota1 + nota2 + nota3) / 3.0;
        
        int conceito;
        
        // Verificar se tem mais de 5 faltas
        if (faltas > 5) {
            conceito = 0;
            System.out.println("Aluno reprovado por faltas (mais de 5 faltas).");
        } else {
            // Determinar conceito baseado na média
            if (media < 6.0) {
                conceito = 0;
            } else if (media < 7.0) {
                conceito = 1;
            } else if (media < 8.0) {
                conceito = 2;
            } else if (media < 9.0) {
                conceito = 3;
            } else {
                conceito = 4;
            }
        }
        
        System.out.println("Média: " + String.format("%.2f", media));
        System.out.println("Faltas: " + faltas);
        System.out.println("Conceito: " + conceito);
        
        scanner.close();
    }
}