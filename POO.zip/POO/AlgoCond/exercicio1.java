// Exercício 1: Verificar se pessoa é maior ou menor de idade

import java.util.Scanner;

public class VerificarMaioridade {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite a idade da pessoa: ");
        int idade = scanner.nextInt();
        
        if (idade >= 18) {
            System.out.println("A pessoa é maior de idade.");
        } else {
            System.out.println("A pessoa é menor de idade.");
        }
        
        scanner.close();
    }
}