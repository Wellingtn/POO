// Exercício 10: Herança com Métodos na Superclasse

// Superclasse Equipamento
class Equipamento {
    protected String nome;
    protected boolean ligado;
    protected String modelo;
    
    public Equipamento() {
        this.ligado = false; // Equipamento inicia desligado
    }
    
    public Equipamento(String nome, String modelo) {
        this.nome = nome;
        this.modelo = modelo;
        this.ligado = false;
    }
    
    // Método da superclasse que será herdado
    public void ligar() {
        if (!ligado) {
            ligado = true;
            System.out.println("Equipamento " + nome + " foi ligado!");
            System.out.println("Status: LIGADO");
        } else {
            System.out.println("Equipamento " + nome + " já está ligado!");
        }
    }
    
    public void desligar() {
        if (ligado) {
            ligado = false;
            System.out.println("Equipamento " + nome + " foi desligado!");
            System.out.println("Status: DESLIGADO");
        } else {
            System.out.println("Equipamento " + nome + " já está desligado!");
        }
    }
    
    public boolean isLigado() {
        return ligado;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    
    public String getNome() {
        return nome;
    }
    
    public String getModelo() {
        return modelo;
    }
    
    public void exibirStatus() {
        System.out.println("=== STATUS DO EQUIPAMENTO ===");
        System.out.println("Nome: " + nome);
        System.out.println("Modelo: " + modelo);
        System.out.println("Status: " + (ligado ? "LIGADO" : "DESLIGADO"));
        System.out.println("=============================");
    }
}

// Subclasse Computador (SEM sobrescrever o método ligar)
class Computador extends Equipamento {
    private String sistemaOperacional;
    private int memoriaRAM; // em GB
    
    public Computador() {
        super();
    }
    
    public Computador(String nome, String modelo, String sistemaOperacional, int memoriaRAM) {
        super(nome, modelo);
        this.sistemaOperacional = sistemaOperacional;
        this.memoriaRAM = memoriaRAM;
    }
    
    public void setSistemaOperacional(String sistemaOperacional) {
        this.sistemaOperacional = sistemaOperacional;
    }
    
    public void setMemoriaRAM(int memoriaRAM) {
        this.memoriaRAM = memoriaRAM;
    }
    
    public String getSistemaOperacional() {
        return sistemaOperacional;
    }
    
    public int getMemoriaRAM() {
        return memoriaRAM;
    }
    
    // Método específico do computador
    public void inicializarSistema() {
        if (ligado) {
            System.out.println("Inicializando " + sistemaOperacional + "...");
            System.out.println("Sistema operacional carregado com sucesso!");
            System.out.println("Memória RAM disponível: " + memoriaRAM + " GB");
        } else {
            System.out.println("Erro: Computador precisa estar ligado para inicializar o sistema!");
        }
    }
    
    public void executarPrograma(String programa) {
        if (ligado) {
            System.out.println("Executando programa: " + programa);
        } else {
            System.out.println("Erro: Computador precisa estar ligado para executar programas!");
        }
    }
    
    @Override
    public void exibirStatus() {
        System.out.println("=== STATUS DO COMPUTADOR ===");
        System.out.println("Nome: " + nome);
        System.out.println("Modelo: " + modelo);
        System.out.println("Sistema Operacional: " + sistemaOperacional);
        System.out.println("Memória RAM: " + memoriaRAM + " GB");
        System.out.println("Status: " + (ligado ? "LIGADO" : "DESLIGADO"));
        System.out.println("============================");
    }
}

// Classe principal para teste
public class Main {
    public static void main(String[] args) {
        // Criando objeto da subclasse Computador
        Computador computador = new Computador();
        
        // Definindo propriedades
        computador.setNome("PC Gamer");
        computador.setModelo("Dell OptiPlex");
        computador.setSistemaOperacional("Windows 11");
        computador.setMemoriaRAM(16);
        
        // Exibindo status inicial
        System.out.println("Status inicial:");
        computador.exibirStatus();
        
        System.out.println("\n--- Tentando inicializar sistema com computador desligado ---");
        computador.inicializarSistema();
        
        System.out.println("\n--- Ligando o computador (método da superclasse) ---");
        // Chamando método ligar() da superclasse (sem sobrescrita)
        computador.ligar();
        
        System.out.println("\n--- Inicializando sistema após ligar ---");
        computador.inicializarSistema();
        
        System.out.println("\n--- Executando programa ---");
        computador.executarPrograma("Visual Studio Code");
        
        System.out.println("\n--- Status final ---");
        computador.exibirStatus();
        
        System.out.println("\n--- Testando método herdado novamente ---");
        computador.ligar(); // Tentando ligar novamente
        
        System.out.println("\n--- Desligando computador ---");
        computador.desligar();
        
        System.out.println("\n--- Usando construtor completo ---");
        Computador notebook = new Computador("Notebook", "MacBook Pro", "macOS", 32);
        notebook.exibirStatus();
        notebook.ligar(); // Método da superclasse
        notebook.inicializarSistema();
    }
}