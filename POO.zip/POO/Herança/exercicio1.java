// Exercício 1: Criação de Superclasse e Subclasse

// Superclasse Pessoa
class Pessoa {
    protected String nome;
    protected int idade;
    
    public Pessoa() {}
    
    public Pessoa(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public void setIdade(int idade) {
        this.idade = idade;
    }
    
    public String getNome() {
        return nome;
    }
    
    public int getIdade() {
        return idade;
    }
}

// Subclasse Aluno
class Aluno extends Pessoa {
    private String matricula;
    
    public Aluno() {}
    
    public Aluno(String nome, int idade, String matricula) {
        super(nome, idade);
        this.matricula = matricula;
    }
    
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
    
    public String getMatricula() {
        return matricula;
    }
    
    public void exibirDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Matrícula: " + matricula);
    }
}

// Classe principal para teste
public class Main {
    public static void main(String[] args) {
        // Criando objeto da classe Aluno
        Aluno aluno = new Aluno();
        
        // Atribuindo valores aos atributos herdados
        aluno.setNome("João Silva");
        aluno.setIdade(20);
        
        // Atribuindo valor ao atributo específico da subclasse
        aluno.setMatricula("2024001");
        
        // Exibindo os dados
        System.out.println("Dados do Aluno:");
        aluno.exibirDados();
        
        // Alternativamente, criando com construtor
        Aluno aluno2 = new Aluno("Maria Santos", 19, "2024002");
        System.out.println("\nDados do Aluno 2:");
        aluno2.exibirDados();
    }
}