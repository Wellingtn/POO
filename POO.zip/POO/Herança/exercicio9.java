// Exercício 9: Herança sem Modificadores de Acesso

// Superclasse Documento (atributos sem modificadores de acesso - package-private)
class Documento {
    String titulo;    // Sem modificador = package-private
    String conteudo;  // Sem modificador = package-private
    
    // Construtor sem modificador
    Documento() {}
    
    Documento(String titulo, String conteudo) {
        this.titulo = titulo;
        this.conteudo = conteudo;
    }
    
    // Métodos sem modificadores de acesso
    void exibirDocumento() {
        System.out.println("=== DOCUMENTO ===");
        System.out.println("Título: " + titulo);
        System.out.println("Conteúdo: " + conteudo);
        System.out.println("=================");
    }
    
    void editarTitulo(String novoTitulo) {
        titulo = novoTitulo;
        System.out.println("Título alterado para: " + titulo);
    }
    
    void editarConteudo(String novoConteudo) {
        conteudo = novoConteudo;
        System.out.println("Conteúdo alterado!");
    }
}

// Subclasse Artigo
class Artigo extends Documento {
    String autor;  // Sem modificador de acesso
    
    // Construtor sem modificador
    Artigo() {}
    
    Artigo(String titulo, String conteudo, String autor) {
        // Chamando construtor da superclasse
        super(titulo, conteudo);
        this.autor = autor;
    }
    
    // Método sem modificador de acesso
    void exibirArtigo() {
        System.out.println("=== ARTIGO ===");
        System.out.println("Título: " + titulo);    // Acesso direto ao atributo da superclasse
        System.out.println("Autor: " + autor);
        System.out.println("Conteúdo: " + conteudo); // Acesso direto ao atributo da superclasse
        System.out.println("==============");
    }
    
    void definirAutor(String nomeAutor) {
        autor = nomeAutor;
        System.out.println("Autor definido: " + autor);
    }
    
    void publicarArtigo() {
        System.out.println("Artigo publicado:");
        System.out.println("'" + titulo + "' por " + autor);
    }
    
    // Método que manipula atributos da superclasse e subclasse
    void criarResumo() {
        String resumo;
        if (conteudo != null && conteudo.length() > 50) {
            resumo = conteudo.substring(0, 50) + "...";
        } else {
            resumo = conteudo;
        }
        
        System.out.println("=== RESUMO DO ARTIGO ===");
        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Resumo: " + resumo);
        System.out.println("========================");
    }
}

// Classe principal para teste
class Main {
    public static void main(String[] args) {
        // Instanciando objeto da subclasse
        Artigo artigo = new Artigo();
        
        // Manipulando atributos sem usar modificadores de acesso
        // (acesso direto aos atributos)
        artigo.titulo = "Introdução à Programação Java";
        artigo.conteudo = "Java é uma linguagem de programação orientada a objetos que foi desenvolvida pela Sun Microsystems e hoje é mantida pela Oracle Corporation.";
        artigo.autor = "Prof. João Silva";
        
        // Exibindo o artigo
        System.out.println("Artigo criado com atribuição direta:");
        artigo.exibirArtigo();
        
        System.out.println("\n--- Modificando atributos diretamente ---");
        // Modificação direta dos atributos
        artigo.titulo = "Programação Orientada a Objetos em Java";
        artigo.autor = "Dra. Maria Santos";
        artigo.conteudo = "A Programação Orientada a Objetos (POO) é um paradigma fundamental no desenvolvimento de software moderno, especialmente em Java.";
        
        artigo.exibirArtigo();
        
        System.out.println("\n--- Usando métodos ---");
        artigo.criarResumo();
        artigo.publicarArtigo();
        
        System.out.println("\n--- Usando construtor ---");
        Artigo artigo2 = new Artigo(
            "Herança em Java", 
            "A herança é um dos pilares da programação orientada a objetos, permitindo que classes filhas herdem características de classes pai.",
            "Prof. Carlos Oliveira"
        );
        
        artigo2.exibirArtigo();
        artigo2.criarResumo();
    }
}