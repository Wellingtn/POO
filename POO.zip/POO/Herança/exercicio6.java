// Exercício 6: Herança com Mais de Uma Subclasse

// Superclasse Pessoa
class Pessoa {
    protected String nome;
    protected int idade;
    
    public Pessoa() {}
    
    public Pessoa(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public void setIdade(int idade) {
        this.idade = idade;
    }
    
    public String getNome() {
        return nome;
    }
    
    public int getIdade() {
        return idade;
    }
    
    public void exibirDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
    }
}

// Primeira subclasse: Professor
class Professor extends Pessoa {
    private String disciplina;
    
    public Professor() {}
    
    public Professor(String nome, int idade, String disciplina) {
        super(nome, idade);
        this.disciplina = disciplina;
    }
    
    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }
    
    public String getDisciplina() {
        return disciplina;
    }
    
    @Override
    public void exibirDados() {
        System.out.println("=== DADOS DO PROFESSOR ===");
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Disciplina: " + disciplina);
        System.out.println("==========================");
    }
}

// Segunda subclasse: Aluno
class Aluno extends Pessoa {
    private String matricula;
    
    public Aluno() {}
    
    public Aluno(String nome, int idade, String matricula) {
        super(nome, idade);
        this.matricula = matricula;
    }
    
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
    
    public String getMatricula() {
        return matricula;
    }
    
    @Override
    public void exibirDados() {
        System.out.println("=== DADOS DO ALUNO ===");
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Matrícula: " + matricula);
        System.out.println("======================");
    }
}

// Classe principal para teste
public class Main {
    public static void main(String[] args) {
        // Criando objetos das subclasses Professor e Aluno
        
        // Criando Professor
        Professor professor = new Professor();
        professor.setNome("Dr. José Santos");
        professor.setIdade(45);
        professor.setDisciplina("Matemática");
        
        // Criando Aluno
        Aluno aluno = new Aluno();
        aluno.setNome("Maria Silva");
        aluno.setIdade(20);
        aluno.setMatricula("2024001");
        
        // Exibindo dados
        System.out.println("Informações das pessoas cadastradas:\n");
        professor.exibirDados();
        System.out.println();
        aluno.exibirDados();
        
        System.out.println("\n--- Usando construtores ---");
        Professor prof2 = new Professor("Ana Costa", 38, "Física");
        Aluno aluno2 = new Aluno("Pedro Oliveira", 19, "2024002");
        
        System.out.println();
        prof2.exibirDados();
        System.out.println();
        aluno2.exibirDados();
    }
}