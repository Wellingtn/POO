// Exercício 5: Herança com Métodos e Construtores

// Superclasse Produto
class Produto {
    protected String nome;
    protected double preco;
    
    public Produto() {}
    
    public Produto(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public void setPreco(double preco) {
        this.preco = preco;
    }
    
    public String getNome() {
        return nome;
    }
    
    public double getPreco() {
        return preco;
    }
    
    // Método que exibe nome e preço do produto
    public void exibirDados() {
        System.out.println("Produto: " + nome);
        System.out.println("Preço: R$ " + String.format("%.2f", preco));
    }
}

// Subclasse Eletronico
class Eletronico extends Produto {
    private int garantia; // em meses
    
    public Eletronico() {}
    
    public Eletronico(String nome, double preco, int garantia) {
        super(nome, preco);
        this.garantia = garantia;
    }
    
    public void setGarantia(int garantia) {
        this.garantia = garantia;
    }
    
    public int getGarantia() {
        return garantia;
    }
    
    // Sobrescrevendo o método da superclasse para incluir garantia
    @Override
    public void exibirDados() {
        System.out.println("Produto Eletrônico: " + nome);
        System.out.println("Preço: R$ " + String.format("%.2f", preco));
        System.out.println("Garantia: " + garantia + " meses");
    }
    
    public void exibirDadosCompletos() {
        System.out.println("=== DADOS DO PRODUTO ELETRÔNICO ===");
        System.out.println("Nome: " + nome);
        System.out.println("Preço: R$ " + String.format("%.2f", preco));
        System.out.println("Garantia: " + garantia + " meses");
        System.out.println("===================================");
    }
}

// Classe principal para teste
public class Main {
    public static void main(String[] args) {
        // Criando objeto da subclasse Eletronico
        Eletronico eletronico = new Eletronico();
        
        // Definindo valores
        eletronico.setNome("Smartphone Samsung Galaxy");
        eletronico.setPreco(1299.99);
        eletronico.setGarantia(12);
        
        // Exibindo dados do produto eletrônico
        System.out.println("Dados do produto eletrônico:");
        eletronico.exibirDados();
        
        System.out.println("\n--- Usando construtor ---");
        Eletronico notebook = new Eletronico("Notebook Dell Inspiron", 2599.90, 24);
        notebook.exibirDadosCompletos();
        
        System.out.println("\n--- Comparando com produto comum ---");
        Produto produtoComum = new Produto("Caneta Bic", 2.50);
        produtoComum.exibirDados();
    }
}