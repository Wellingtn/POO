// Exercício 4: Uso de Atributos Protegidos

// Superclasse Funcionario
class Funcionario {
    protected String nome;
    protected double salario; // Atributo protegido
    
    public Funcionario() {}
    
    public Funcionario(String nome) {
        this.nome = nome;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String getNome() {
        return nome;
    }
    
    public double getSalario() {
        return salario;
    }
    
    public void exibirDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Salário: R$ " + String.format("%.2f", salario));
    }
}

// Subclasse Gerente
class Gerente extends Funcionario {
    private String departamento;
    
    public Gerente() {}
    
    public Gerente(String nome, String departamento) {
        super(nome);
        this.departamento = departamento;
    }
    
    // Construtor que inicializa o atributo protegido salario
    public Gerente(String nome, String departamento, double salario) {
        super(nome);
        this.departamento = departamento;
        this.salario = salario; // Acesso direto ao atributo protegido
    }
    
    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }
    
    public String getDepartamento() {
        return departamento;
    }
    
    // Método para definir salário (acessando atributo protegido)
    public void definirSalario(double salario) {
        if (salario > 0) {
            this.salario = salario; // Acesso direto ao atributo protegido
        } else {
            System.out.println("Salário deve ser positivo!");
        }
    }
    
    @Override
    public void exibirDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Departamento: " + departamento);
        System.out.println("Salário: R$ " + String.format("%.2f", salario));
    }
}

// Classe principal para teste
public class Main {
    public static void main(String[] args) {
        // Criando objeto de Gerente
        Gerente gerente = new Gerente("Ana Silva", "Vendas");
        
        // Atribuindo valor ao atributo protegido salario através do método
        gerente.definirSalario(8500.00);
        
        System.out.println("Dados do Gerente:");
        gerente.exibirDados();
        
        System.out.println("\n--- Criando gerente com construtor completo ---");
        Gerente gerente2 = new Gerente("Carlos Oliveira", "TI", 9200.50);
        gerente2.exibirDados();
        
        System.out.println("\n--- Testando validação de salário ---");
        gerente2.definirSalario(-1000); // Deve mostrar erro
    }
}