// Exercício 8: Acessando Atributos da Superclasse

// Superclasse Veiculo
class Veiculo {
    protected double capacidadeTanque; // em litros
    protected String marca;
    
    public Veiculo() {}
    
    public Veiculo(String marca, double capacidadeTanque) {
        this.marca = marca;
        this.capacidadeTanque = capacidadeTanque;
    }
    
    public void setCapacidadeTanque(double capacidadeTanque) {
        this.capacidadeTanque = capacidadeTanque;
    }
    
    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    public double getCapacidadeTanque() {
        return capacidadeTanque;
    }
    
    public String getMarca() {
        return marca;
    }
}

// Subclasse Carro
class Carro extends Veiculo {
    private String modelo;
    private int numPortas;
    
    public Carro() {}
    
    public Carro(String marca, double capacidadeTanque, String modelo, int numPortas) {
        super(marca, capacidadeTanque);
        this.modelo = modelo;
        this.numPortas = numPortas;
    }
    
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    
    public void setNumPortas(int numPortas) {
        this.numPortas = numPortas;
    }
    
    public String getModelo() {
        return modelo;
    }
    
    public int getNumPortas() {
        return numPortas;
    }
    
    // Método que imprime o valor do atributo da superclasse
    public void exibirCapacidadeTanque() {
        System.out.println("Capacidade do tanque: " + capacidadeTanque + " litros");
    }
    
    // Método adicional para exibir informações completas
    public void exibirInformacoes() {
        System.out.println("=== INFORMAÇÕES DO CARRO ===");
        System.out.println("Marca: " + marca); // Acesso ao atributo da superclasse
        System.out.println("Modelo: " + modelo);
        System.out.println("Número de Portas: " + numPortas);
        System.out.println("Capacidade do Tanque: " + capacidadeTanque + " litros"); // Atributo da superclasse
        System.out.println("============================");
    }
    
    // Método que calcula autonomia estimada
    public void calcularAutonomia(double consumoPorLitro) {
        double autonomia = capacidadeTanque * consumoPorLitro; // Usando atributo da superclasse
        System.out.println("Autonomia estimada: " + String.format("%.1f", autonomia) + " km");
        System.out.println("(Baseado em " + consumoPorLitro + " km/l)");
    }
}

// Classe principal para teste
public class Main {
    public static void main(String[] args) {
        // Criando objeto da subclasse Carro
        Carro carro = new Carro();
        
        // Definindo valores
        carro.setMarca("Honda");
        carro.setCapacidadeTanque(50.0);
        carro.setModelo("Civic");
        carro.setNumPortas(4);
        
        // Utilizando o método que acessa atributo da superclasse
        System.out.println("Testando acesso ao atributo da superclasse:");
        carro.exibirCapacidadeTanque();
        
        System.out.println("\n--- Informações completas do carro ---");
        carro.exibirInformacoes();
        
        System.out.println("\n--- Calculando autonomia ---");
        carro.calcularAutonomia(12.5);
        
        System.out.println("\n--- Usando construtor ---");
        Carro carro2 = new Carro("Toyota", 45.0, "Corolla", 4);
        carro2.exibirCapacidadeTanque();
        carro2.calcularAutonomia(14.2);
    }
}