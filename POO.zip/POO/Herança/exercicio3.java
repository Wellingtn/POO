// Exercício 3: Construtores em Herança

// Superclasse Animal
class Animal {
    protected String nome;
    
    // Construtor da superclasse
    public Animal(String nome) {
        this.nome = nome;
        System.out.println("Construtor da classe Animal chamado para: " + nome);
    }
    
    public String getNome() {
        return nome;
    }
    
    public void emitirSom() {
        System.out.println(nome + " faz algum som...");
    }
}

// Subclasse Cachorro
class Cachorro extends Animal {
    
    // Construtor da subclasse que chama o construtor da superclasse
    public Cachorro(String nome) {
        super(nome); // Chamada ao construtor da superclasse
        System.out.println("Construtor da classe Cachorro chamado para: " + nome);
    }
    
    // Sobrescrevendo o método da superclasse
    @Override
    public void emitirSom() {
        System.out.println(nome + " faz: Au au!");
    }
    
    public void abanarRabo() {
        System.out.println(nome + " está abanando o rabo!");
    }
}

// Classe principal para teste
public class Main {
    public static void main(String[] args) {
        System.out.println("Criando um cachorro:");
        Cachorro cachorro = new Cachorro("Rex");
        
        System.out.println("\nTestando métodos:");
        cachorro.emitirSom();
        cachorro.abanarRabo();
        
        System.out.println("\nNome do animal: " + cachorro.getNome());
        
        System.out.println("\n--- Criando outro cachorro ---");
        Cachorro cachorro2 = new Cachorro("Bella");
        cachorro2.emitirSom();
    }
}