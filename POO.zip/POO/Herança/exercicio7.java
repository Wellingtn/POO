// Exercício 7: Herança em Cadeia

// Superclasse SerVivo
class SerVivo {
    protected String nomeCientifico;
    protected int idade;
    
    public SerVivo() {}
    
    public SerVivo(String nomeCientifico, int idade) {
        this.nomeCientifico = nomeCientifico;
        this.idade = idade;
    }
    
    public void setNomeCientifico(String nomeCientifico) {
        this.nomeCientifico = nomeCientifico;
    }
    
    public void setIdade(int idade) {
        this.idade = idade;
    }
    
    public String getNomeCientifico() {
        return nomeCientifico;
    }
    
    public int getIdade() {
        return idade;
    }
    
    public void exibirDados() {
        System.out.println("Nome Científico: " + nomeCientifico);
        System.out.println("Idade: " + idade + " anos");
    }
}

// Primeira subclasse: Animal (herda de SerVivo)
class Animal extends SerVivo {
    protected String habitat;
    
    public Animal() {}
    
    public Animal(String nomeCientifico, int idade, String habitat) {
        super(nomeCientifico, idade);
        this.habitat = habitat;
    }
    
    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }
    
    public String getHabitat() {
        return habitat;
    }
    
    @Override
    public void exibirDados() {
        System.out.println("Nome Científico: " + nomeCientifico);
        System.out.println("Idade: " + idade + " anos");
        System.out.println("Habitat: " + habitat);
    }
}

// Segunda subclasse: Mamifero (herda de Animal)
class Mamifero extends Animal {
    protected String alimentacao;
    
    public Mamifero() {}
    
    public Mamifero(String nomeCientifico, int idade, String habitat, String alimentacao) {
        super(nomeCientifico, idade, habitat);
        this.alimentacao = alimentacao;
    }
    
    public void setAlimentacao(String alimentacao) {
        this.alimentacao = alimentacao;
    }
    
    public String getAlimentacao() {
        return alimentacao;
    }
    
    @Override
    public void exibirDados() {
        System.out.println("=== DADOS DO MAMÍFERO ===");
        System.out.println("Nome Científico: " + nomeCientifico);
        System.out.println("Idade: " + idade + " anos");
        System.out.println("Habitat: " + habitat);
        System.out.println("Alimentação: " + alimentacao);
        System.out.println("=========================");
    }
    
    public void amamentar() {
        System.out.println("Este mamífero pode amamentar seus filhotes.");
    }
}

// Classe principal para teste
public class Main {
    public static void main(String[] args) {
        // Criando objeto da classe Mamifero (final da cadeia de herança)
        Mamifero mamifero = new Mamifero();
        
        // Atribuindo valores a todos os atributos da cadeia de herança
        // Atributos de SerVivo
        mamifero.setNomeCientifico("Panthera leo");
        mamifero.setIdade(8);
        
        // Atributo de Animal
        mamifero.setHabitat("Savana africana");
        
        // Atributo de Mamifero
        mamifero.setAlimentacao("Carnívora");
        
        // Exibindo todos os dados
        System.out.println("Dados do mamífero criado:");
        mamifero.exibirDados();
        mamifero.amamentar();
        
        System.out.println("\n--- Usando construtor completo ---");
        Mamifero elefante = new Mamifero("Loxodonta africana", 25, "Savana e florestas", "Herbívora");
        elefante.exibirDados();
        elefante.amamentar();
        
        System.out.println("\n--- Testando a cadeia de herança ---");
        System.out.println("Acessos diretos aos atributos herdados:");
        System.out.println("Nome científico (de SerVivo): " + elefante.getNomeCientifico());
        System.out.println("Habitat (de Animal): " + elefante.getHabitat());
        System.out.println("Alimentação (de Mamifero): " + elefante.getAlimentacao());
    }
}