// Exercício 2: Herança com Atributos

// Superclasse Veiculo
class Veiculo {
    protected String marca;
    protected String modelo;
    protected int ano;
    
    public Veiculo() {}
    
    public Veiculo(String marca, String modelo, int ano) {
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
    }
    
    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    
    public void setAno(int ano) {
        this.ano = ano;
    }
    
    public String getMarca() {
        return marca;
    }
    
    public String getModelo() {
        return modelo;
    }
    
    public int getAno() {
        return ano;
    }
}

// Subclasse Carro
class Carro extends Veiculo {
    private int numPortas;
    
    public Carro() {}
    
    public Carro(String marca, String modelo, int ano, int numPortas) {
        super(marca, modelo, ano);
        this.numPortas = numPortas;
    }
    
    public void setNumPortas(int numPortas) {
        this.numPortas = numPortas;
    }
    
    public int getNumPortas() {
        return numPortas;
    }
    
    public void exibirDados() {
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Ano: " + ano);
        System.out.println("Número de Portas: " + numPortas);
    }
}

// Classe principal para teste
public class Main {
    public static void main(String[] args) {
        // Criando objeto da subclasse Carro
        Carro carro = new Carro();
        
        // Atribuindo valores aos atributos da superclasse
        carro.setMarca("Toyota");
        carro.setModelo("Corolla");
        carro.setAno(2023);
        
        // Atribuindo valor ao atributo da subclasse
        carro.setNumPortas(4);
        
        // Exibindo os dados
        System.out.println("Dados do Carro:");
        carro.exibirDados();
        
        // Alternativamente, usando construtor
        Carro carro2 = new Carro("Honda", "Civic", 2022, 2);
        System.out.println("\nDados do Carro 2:");
        carro2.exibirDados();
    }
}